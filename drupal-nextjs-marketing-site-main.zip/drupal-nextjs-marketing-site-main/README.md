# example-marketing

An example marketing site built using Drupal + JSON:API.

Pages are built from the Landing page node type and paragraphs sourced from `/drupal`.

See https://demo.next-drupal.org

## License

Licensed under the [MIT license](https://github.com/chapter-three/next-drupal/blob/master/LICENSE).
